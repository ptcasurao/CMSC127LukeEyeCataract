UI makes use of Bootstrap & JQuery
- bootstrap and jquery are temporarily linked online, therefore, for the page to work completely, internet access is needed
- bootstrap and jquery files will be downloaded and added into the UI after it has been finalized

UI uses PHP-mysql extensions for processing MYSQL commands
- php version must be updated with this extension for the UI sqlcommands to work
