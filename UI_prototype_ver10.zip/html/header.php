<?php

// HEADER

echo '<div id="heading" style="background: linear-gradient(to bottom right, rgba(92, 184, 92, 0.9) 20%, rgba(92, 184, 92, 0) 100%); padding: 10px; width: calc(100% - 100px); height:60px; margin-bottom: 10px;">
  <div>
  <img class="media-object" style="float:left; height:40px; margin-left:15px; opacity:0.9;" src="/images/luke_logo.bmp">
  </div>
  <p style="float:left; font-size:16pt; color:#ffffff; margin: 5px 20px;"> LUKE FOUNDATION, INC. </p>
</div>';

// HEADER END

?>